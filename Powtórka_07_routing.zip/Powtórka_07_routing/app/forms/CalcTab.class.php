<?php
        namespace app\forms;
//tutaj będą zapisane wartości
    class CalcTab{
        
        public $kwota;
        public $czas;
        public $oprocentowanie;
        
        
    }

