<?php
// W skrypcie definicji kontrolera nie trzeba dołączać problematycznego skryptu config.php, 
            
// Konfiguracja, Messages i Smarty są dostępne za pomocą odpowiednich funkcji.
// Kontroler ładuje tylko to z czego sam korzysta.


// W skrypcie definicji kontrolera nie trzeba dołączać już niczego.
// Kontroler wskazuje tylko za pomocą 'use' te klasy z których jawnie korzysta
// (gdy korzysta niejawnie to nie musi - np używa obiektu zwracanego przez funkcję)

// Zarejestrowany autoloader klas załaduje odpowiedni plik automatycznie w momencie, gdy skrypt będzie go chciał użyć.
// Jeśli nie wskaże się klasy za pomocą 'use', to PHP będzie zakładać, iż klasa znajduje się w bieżącej
// przestrzeni nazw - tutaj jest to przestrzeń 'app\controllers'.

// Przypominam, że tu również są dostępne globalne funkcje pomocnicze - o to nam właściwie chodziło



namespace app\controllers;

//zamieniamy zatem 'require' na 'use' wskazując jedynie przestrzeń nazw, w której znajduje się klasa
use app\forms\CalcTab;
use app\transfer\CalcResult;



		//jest są to obiekty reprezentujące dane 
                //obiekt prywatny tab reprezentuje dane formularza czyli kwota, oprocentowanie, czas
    
                class CalcCtrl
                {
                   
                    private $tab;
                    private $result;
                
                   
                    //__construct mozna zwykłą nazwą dać i wywolac w equals, tak to nie trzeba wywoływać
                    public function __construct()
                    {
                        //na tym tabie tworze obiekt ^^
                        //this->tab->kwota == tab.kwota
                        $this->tab = new CalcTab();
                        $this->result = new CalcResult();
                       
                        
                        
                    }
                    
                    
                    
                    
                    


                    public function getParams()
			{
				$this->tab->kwota = getFromRequest('kwota');
				$this->tab->czas = getFromRequest('czas');
				$this->tab->oprocentowanie = getFromRequest('oprocentowanie');
			}
                        
                        
                    
                    
                    
                    
                    public function validate()
		{
			//isset respektuje null
			//czemu isset raz jest ustawiony a raz nie
			//!!po co to jest? daje to tylko to ze nie wyswietla sie po starcie messages brak kwoty... i dlaczego tak dziala isset jak caly czas jest null?
			
			if (  (!isset($this->tab->kwota) || !isset($this->tab->oprocentowanie) || !isset($this->tab->czas)) ) return false;  //po co to jest!
		
			if($this->tab->kwota =="")   getMessages()->addError("Nie podano kwoty!");
			if($this->tab->oprocentowanie =="")   getMessages()->addError("Nie podano wartości oprocentowania!");
			
                        if(getMessages()->isGood())
                        {
                            if( !is_numeric($this->tab->kwota))   getMessages()->addError("Podana kwota nie jest liczbą!");
			if( !is_numeric($this->tab->oprocentowanie)) getMessages()->addError("Podane oprocentowanie nie jest liczbą!");
                        return true;
                            
                        } return getMessages()->isGood();
                }
                
                
                
                
                
                
               
			
			
                        /** 
	 * Pobranie wartości, walidacja, obliczenie i wyświetlenie
	 */
                   
                        
                        
                        public function action_calcCompute()
			{
                            
                            $this->getParams();
                            
                            if($this->validate())
                            {
                    
				getMessages()->addInfo("Obliczam...");
				$this->result->result= $this->tab->kwota/$this->tab->czas + $this->tab->kwota/$this->tab->czas*$this->tab->oprocentowanie/100;
                                $this->result->result = round($this->result->result,2);
                                
                                getMessages()->addInfo('Wykonano obliczenia.');
                            }
                            $this->generateView();
			}
			
			
			public function action_calcShow(){
		getMessages()->addInfo('Witaj w kalkulatorze');
		$this->generateView();
	}
					
		
                        
                        
              
public function       generateView(){
                //nie trzeba już tworzyć Smarty i przekazywać mu konfiguracji i messages
		// - wszystko załatwia funkcja getSmarty()
                
    //
    
                getSmarty()->assign('page_title','07 role');
		getSmarty()->assign('page_description','...');
		getSmarty()->assign('page_header','...');
                
                
               getSmarty()->assign('user',unserialize($_SESSION['user']));
				
		
                
	       getSmarty()->assign('tab',$this->tab);
	       getSmarty()->assign('result',$this->result);
		
		getSmarty()->display('Cal_view.tpl');  // już nie podajemy pełnej ścieżki - foldery widoków są zdefiniowane przy ładowaniu Smarty
	}


    

}





