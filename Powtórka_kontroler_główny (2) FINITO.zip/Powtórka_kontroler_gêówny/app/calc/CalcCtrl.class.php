<?php
// W skrypcie definicji kontrolera nie trzeba dołączać problematycznego skryptu config.php,
// ponieważ będzie on użyty w miejscach, gdzie config.php zostanie już wywołany.  ????

         //z kąd on wykrywa conf??? podpowiedź jak nie podłączamy configa a wczesniej podłanczaliśmy      
            
require_once $conf->root_path.'/lib/Smarty.class.php';
require_once $conf->root_path.'/lib/Messages.class.php';
require_once $conf->root_path.'/app/calc/CalcTab.class.php';
require_once $conf->root_path.'/app/calc/CalcResult.class.php';





		//jest są to obiekty reprezentujące dane 
                //obiekt prywatny tab reprezentuje dane formularza czyli kwota, oprocentowanie, czas
    
                class CalcCtrl
                {
                   
                    private $tab;
                    private $result;
                    private $messages;
                   
                    //__construct mozna zwykłą nazwą dać i wywolac w equals, tak to nie trzeba wywoływać
                    public function __construct()
                    {
                        //na tym tabie tworze obiekt ^^
                        //this->tab->kwota == tab.kwota
                        $this->tab = new CalcTab();
                        $this->result = new CalcResult();
                        $this->messages = new Messages();
                        
                        
                    }
                    
                    
                    
                    
                    


                    public function getParams()
			{
				$this->tab->kwota = isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
				$this->tab->czas = isset($_REQUEST['czas']) ? $_REQUEST['czas'] : 24;
				$this->tab->oprocentowanie = isset($_REQUEST['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
			}
                        
                        
                    
                    
                    
                    
                    public function validate()
		{
			//isset respektuje null
			//czemu isset raz jest ustawiony a raz nie
			//!!po co to jest? daje to tylko to ze nie wyswietla sie po starcie messages brak kwoty... i dlaczego tak dziala isset jak caly czas jest null?
			
			if (  (!isset($this->tab->kwota) || !isset($this->tab->oprocentowanie) || !isset($this->tab->czas)) ) return false;
		
			if($this->tab->kwota =="") $this->messages->addError("Nie podano kwoty!");
			if($this->tab->oprocentowanie =="") $this->messages->addError("Nie podano wartości oprocentowania!");
			
                        if( $this->messages->isGood())
                        {
                            if( !is_numeric($this->tab->kwota)) $this->messages->addError("Podana kwota nie jest liczbą!");
			if( !is_numeric($this->tab->oprocentowanie)) $this->messages->addError("Podane oprocentowanie nie jest liczbą!");
                        return true;
                            
                        } return false;
                }
                
                
                
                
                
                
               
			
			
                        
                   
                        
                        
                        public function equals()
			{
                            
                            $this->getParams();
                            
                            if($this->validate())
                            {
                    
				$this->messages->addInfo("Obliczam...");
				$this->result->result= $this->tab->kwota/$this->tab->czas + $this->tab->kwota/$this->tab->czas*$this->tab->oprocentowanie/100;
                                $this->result->result = round($this->result->result,2);
                                
                                $this->messages->addInfo('Wykonano obliczenia.');
                            }
                            $this->generateView();
			}
			
			
			
					
		
                        
                        
              
public function       generateView(){
		global $conf;   //dzieki global nie tworzy nowej  zmiennej w assign $conf tylko (updatuje, odnosi) sie do zmiennej globalnej wczesniej juz zdefiniowenej przekazywanej przez includy i require
		// musielismy dac global $conf bo inaczej w funkcji nie widzi ani w classie nie widzi, widzi tylko po za classą na samej górze, a w clasie juz nie widzi
                //global działa tylko w funkcjach jak damy w cassie to nie
		$smarty = new Smarty();
		$smarty->assign('conf',$conf);
		
		$smarty->assign('page_title','Przykład 05');
		$smarty->assign('page_description','Obiektowość. Funkcjonalność aplikacji zamknięta w metodach różnych obiektów. Pełen model MVC.');
		$smarty->assign('page_header','Obiekty w PHP');
				
		$smarty->assign('messages',$this->messages);
		$smarty->assign('tab',$this->tab);
		$smarty->assign('result',$this->result);
		
		$smarty->display($conf->root_path.'/app/calc/Cal_view.html');
	}


    

}

