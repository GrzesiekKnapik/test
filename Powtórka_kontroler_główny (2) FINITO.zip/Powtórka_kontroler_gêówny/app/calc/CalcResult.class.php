<?php
    
//tutaj bedzie zapisany wynik

class CalcResult{
    
    public $result;
}

