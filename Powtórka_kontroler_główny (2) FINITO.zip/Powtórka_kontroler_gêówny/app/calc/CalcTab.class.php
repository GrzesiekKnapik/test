<?php
        
//tutaj będą zapisane wartości
    class CalcTab{
        
        public $kwota;
        public $czas;
        public $oprocentowanie;
        
        
    }

