<?php
// Skrypt kontrolera głównego uruchamiający określoną
// akcję użytkownika na podstawie przekazanego parametru

//każdy punkt wejścia aplikacji (skrypt uruchamiany bezpośrednio przez klienta) musi dołączać konfigurację
// - w tym wypadku jest już tylko jeden punkt wejścia do aplikacji - skrypt ctrl.php
require_once dirname(__FILE__).'/../config.php';



//utwórz obiekt i użyj

$action = isset($_REQUEST['action'])? $_REQUEST['action'] : '';




switch($action)
{
    default: //calc_view
        
        require_once $conf->root_path.'/app/calc/CalcCtrl.class.php';
        $ctrl = new CalcCtrl();
        $ctrl->generateView();
        
    break;
        
        
        
    case 'calcCompute':
            
        require_once $conf->root_path.'/app/calc/CalcCtrl.class.php';
        $ctrl = new CalcCtrl();
        $ctrl->equals();
        
    break;
        
        
        
    
    
    
}




