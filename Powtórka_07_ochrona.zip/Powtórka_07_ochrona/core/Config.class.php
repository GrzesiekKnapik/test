<?php namespace core;


class Config
{
    public $server_name;
    public $server_url;
    public $app_root;
    public $app_url;
    public $root_path;
    public $action_root;
    public $action_url;
    
    
}
?>



