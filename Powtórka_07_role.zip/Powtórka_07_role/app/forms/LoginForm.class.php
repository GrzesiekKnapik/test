<?php

namespace app\forms;

class LoginForm {
	public $login;
	public $pass;
} 